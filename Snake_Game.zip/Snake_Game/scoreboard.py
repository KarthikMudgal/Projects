from turtle import Turtle

FONT_SIZE = 15
FONT = "Courier"


class Scoreboard(Turtle):
    SCORE = 0

    def __init__(self):
        super().__init__()
        Scoreboard.SCORE = 0

    def display_score(self):
        self.write(f"Score: {Scoreboard.SCORE}", False, "center", (FONT, FONT_SIZE, 'normal'))

    def game_over(self):
        self.goto(0,0)
        self.write("GAME OVER", False, "center", (FONT, FONT_SIZE, 'normal'))



    def increase_score(self):
        self.clear()
        Scoreboard.SCORE += 1
        self.write(f"Score: {Scoreboard.SCORE}", False, "center", (FONT, FONT_SIZE, 'normal'))
