from turtle import *
from snake import Snake
import time
from food import Food
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.tracer(0)
screen.title("Snake Game")

snake = Snake()
food = Food()
score = Scoreboard()

screen.listen()
screen.onkey(snake.move_up, "Up")
screen.onkey(snake.move_down, "Down")
screen.onkey(snake.move_left, "Left")
screen.onkey(snake.move_right, "Right")

start_pos = [(0, 0), (-20, 0), (-40, 0)]
parts = []
score_x = 0
score_y = 270

score.penup()
score.setx(score_x)
score.sety(score_y)
score.color("white")
score.hideturtle()
score.display_score()
snake.head.shape("circle")
# Moves Snake
game_is_on = True

while game_is_on:
    screen.update()
    time.sleep(0.1)
    snake.move()

    # Detect collision with food.
    if snake.head.distance(food) < 15:
        food.refresh()
        snake.extend()
        score.increase_score()

    # Detect collision with wall
    if snake.head.xcor() > 280 or snake.head.xcor() < -280 or snake.head.ycor() > 280 or snake.head.ycor() < -280:
        game_is_on = False
        score.game_over()

    # Detect collision with tail
    for part in snake.snake_parts[1:]:
        # if head collides with any part in the tail
        if snake.head.distance(part) < 10:
            game_is_on = False
            score.game_over()


screen.exitonclick()
